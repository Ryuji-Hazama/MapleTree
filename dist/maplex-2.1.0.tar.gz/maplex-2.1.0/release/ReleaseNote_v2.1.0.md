# MapleX v2.1.0 Release Note

Dec 21 2025

Here is what's new in Version 2.1.0

## Overview

- Enabled comments in Maple file
- Fixed a small bug in the Logger class

## What's New

### Enabled Comments

- From this version, you can write comments in the Maple file.
  - Use `CMT` tag or `#` for one-line comments.
  - Write multi-line comments inside the comment block which starts with `H #*` and ends with `E *#`.
  - MapleTree will ignore those comment lines.

## Bug Fix

### Logger

- Fixed the logger outputs log levels instead of the caller function name.

## Other Notes

- This is the first official release.

[**Full Changelog**](https://github.com/Ryuji-Hazama/MapleTree/commits/v2.1.0)
